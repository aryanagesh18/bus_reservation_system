export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Bus {
  id: string;
  name: string;
  from: string;
  to: string;
  departureTime: string;
  arrivalTime: string;
  price: number;
  totalSeats: number;
  availableSeats: number;
}

export interface Booking {
  id: string;
  userId: string;
  busId: string;
  seatNumbers: number[];
  totalAmount: number;
  bookingDate: string;
  status: 'confirmed' | 'pending' | 'cancelled';
}