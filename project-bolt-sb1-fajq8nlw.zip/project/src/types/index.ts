export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
}

export interface Bus {
  id: string;
  name: string;
  source: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  price: number;
  availableSeats: number;
  totalSeats: number;
}

export interface Booking {
  id: string;
  userId: string;
  busId: string;
  seatNumbers: number[];
  bookingDate: string;
  totalAmount: number;
  status: 'confirmed' | 'cancelled' | 'pending';
}